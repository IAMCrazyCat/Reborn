//
//  SetUpPage.swift
//  Reborn
//
//  Created by Christian Liu on 20/12/20.
//

import Foundation
struct SetUpPage {
    var question = ""
    var buttons: Array<String> = []
}
