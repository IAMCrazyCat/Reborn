//
//  WaitingForSelectionState.swift
//  Reborn
//
//  Created by Christian Liu on 30/12/20.
//

import Foundation
class WaitingForSelection: SetUpViewBaseState {
    override func handle1() {
        
    }
    
    override func handle2() {
        
    }
}
