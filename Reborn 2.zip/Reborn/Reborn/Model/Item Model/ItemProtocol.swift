//
//  ItemProtocol.swift
//  Reborn
//
//  Created by Christian Liu on 25/12/20.
//

import Foundation
protocol ItemProtocol {
   
}
