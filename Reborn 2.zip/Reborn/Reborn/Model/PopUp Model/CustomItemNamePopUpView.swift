//
//  CustomItemNamePopUpView.swift
//  Reborn
//
//  Created by Christian Liu on 30/12/20.
//

import Foundation
import UIKit
//class CustomItemNamePopUpView: PopUpView {
//    var textFiledTitleLabel: UILabel
//    var textField: UITextField
//    init(textFiledTitleLabel: UILabel, textField: UITextField) {
//        self.textFiledTitleLabel = textFiledTitleLabel
//        self.textField = textField
//    }
//}
