//
//  Day.swift
//  Reborn
//
//  Created by Christian Liu on 28/12/20.
//

import Foundation
enum WeekDay: String, Codable {
    case Monday
    case Tuesday
    case Wednesday
    case Thursday
    case Friday
    case Saturday
    case Sunday
}

