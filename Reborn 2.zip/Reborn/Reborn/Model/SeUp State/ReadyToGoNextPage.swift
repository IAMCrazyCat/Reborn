//
//  ReadyToGoNextPage.swift
//  Reborn
//
//  Created by Christian Liu on 30/12/20.
//

import Foundation
class ReadyToGoNextPage: SetUpViewBaseState {
    
}
